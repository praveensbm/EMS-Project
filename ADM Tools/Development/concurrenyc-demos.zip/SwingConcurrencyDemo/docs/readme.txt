Objective:
------------

1. To understand Progress Bar in swing.
2. To handle concurrency related problem using SwingWorker.


How to run demo:
----------------------
prompt>	cd workspace/project/bin
prompt>	java com.seed.Test

Note:
------

Execute this application and click on start button.
Try closing this application, it'll be closed immediately.

Follow TODO:7, which is in PanelWithProgressBar;
Now again execute this application and click on start button.
Try closing this application, it can't be closed. 


