Objective:
------------

To understand Executors, which manages Threads.

How to run demo:
---------------------

This project contains 3 applications.

1. This application shows use of Callable with Future interface.

	java com.seed.test.future.Test
	
2. This application shows use of Thread pools.
	Both applications solves same problem statement.
	
	java com.seed.test.pool.Test
	
3. This application shows Server which uses Thread pool.

	java com.seed.test.pool.additional.MyServer

		