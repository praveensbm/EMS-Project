package com.seed.test.classlock;

public class TestSynchWithStatic {
	public static void main(String[] args) {

		new Thread("EVEN") {
			@Override
			public void run() {
				
				TestSynchWithStatic.runEvenLoop();
			}
		}.start();

		new Thread("ODD") {
			@Override
			public void run() {
				TestSynchWithStatic.runOddLoop();
			}
		}.start();
		
	}

//	synchronized
	public static void runEvenLoop() {
		try {
			for (int value = 0; value < 50; value++) {
				if (value % 2 == 0){
					System.out.println(Thread.currentThread().getName() + ": "+ value);
					Thread.sleep(800);
				}
					
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

//	synchronized
	public static void runOddLoop() {
		try {
			for (int value = 0; value < 50; value++) {
				if (value % 2 != 0){
					System.out.println(Thread.currentThread().getName() + ": "+ value);
					Thread.sleep(500);
				}					
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
