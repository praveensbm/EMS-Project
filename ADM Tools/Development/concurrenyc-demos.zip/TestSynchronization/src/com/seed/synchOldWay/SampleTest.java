package com.seed.synchOldWay;

public class SampleTest {
	public static void main(String[] args) {
		//TODO:1 Create an object of Bank (Shared Object)

		//TODO:2 Create Runnable job (TransactionWindow) which accesses the shared object

		//TODO:3 Start 2 threads executing the above Runnable Job

		//TODO:4 main thread will wait for completion of these newly created threads

//		thread1.join();
//		thread2.join();

		//TODO:5 Show Total balance in bank.
	}
}
